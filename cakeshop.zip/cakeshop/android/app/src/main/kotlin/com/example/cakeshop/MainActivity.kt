package com.example.cakeshop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
