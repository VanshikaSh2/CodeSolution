import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Welcome to my Cake Shop',
      theme: ThemeData(
        primarySwatch: Colors.yellow,
        colorScheme: ColorScheme.fromSwatch(
          primarySwatch: Colors.deepPurple,
        ),
      ),
      home: const MyCakePage(),
    );
  }
}

class MyCakePage extends StatefulWidget {
  const MyCakePage({Key? key}) : super(key: key);

  @override
  State<MyCakePage> createState() => _MyCakePageState();
}

class _MyCakePageState extends State<MyCakePage> {String cake = '';
  String yourCake = '';
  String vanillaCake = 'Vanilla Cake'; // Initialize cake flavors
  String strawberryCake = 'Strawberry Cake';
  String chocolateCake = 'Chocolate Cake';
  Map<String, List<Map<String, String>>> cakeImages = {
    'vanillaCake':[
      {
        'images':'https://tse4.mm.bing.net/th?id=OIP.QRAmwwS7Nr6E7nghdiO7SwHaE8&pid=Api&P=0&h=180',
        'Description':'Name of Shop: ABC Cake shop,      Time:9:00am-7:00pm,   Price:Rs.350/kg',

      },
      {
        'images':'https://tse1.mm.bing.net/th?id=OIP.t8m2Y_hyNalVcPAOOXF6nwHaHa&pid=Api&P=0&h=180',
        'Description':'Name of Shop: Decent Cake shop,      Time:11:00am-7:00pm,   Price:Rs.650/kg'
      },
      {
        'images':'https://tse1.mm.bing.net/th?id=OIP.79zWY4KTOTmJl8MpVXbW4wHaHa&pid=Api&P=0&h=180',
        'Description':'Name of Shop: DEF Cake shop,      Time:10:00am-7:00pm, Price:Rs.650/kg'
      },
      {
        'images':'https://tse4.mm.bing.net/th?id=OIP.uk-n1Zh_w1rLL2ba44JCZwHaEK&pid=Api&P=0&h=180',
        'Description':'Name of Shop: New Cake shop,      Time:11:00am-6:00pm, Price:Rs.450/kg'
      },
      {
        'images':'https://tse1.mm.bing.net/th?id=OIP.AvvIHw6HXr81_cb3u0LU_AHaLH&pid=Api&P=0&h=180',
        'Description':'Name of Shop: MNF Cake shop,      Time:10:00am-6:00pm, Price:Rs.250/kg'
      }
    ],
    'strawberryCake':
    [
      {

        'images':'https://tse4.mm.bing.net/th?id=OIP.hWHOyAYqa9XBoyiv7A_HQwHaLH&pid=Api&P=0&h=180',
        'Description':'Name of Shop: CRF Cake shop,      Time:12:00pm-6:00pm, Price:Rs.250/kg'
      },
      {
        'images':'https://tse1.mm.bing.net/th?id=OIP.h8fCrlEvgHKdV5jwZkl5hQHaLH&pid=Api&P=0&h=180',
        'Description':'Name of Shop:CP Cake shop,        Time:12:00pm-7:00pm, Price:Rs.500/kg'

      },
      {
        'images':'https://tse3.mm.bing.net/th?id=OIP.p2AguWHrzW1E3OiHFbXFZAHaFb&pid=Api&P=0&h=180',
        'Description':'Name of Shop:CP Cake shop,        Time:12:00pm-7:00pm, Price:Rs.500/kg',

      },
      {
        'images':'https://tse2.mm.bing.net/th?id=OIP.3I3Yekfo6UrFQu8d6L9pjAHaLH&pid=Api&P=0&h=180',
        'Description':'Name of Shop:OP Cake shop,        Time:12:00pm-6:30pm, Price:Rs.700/kg'

      }
    ],
    'chocolateCake':
    [
      {
        'images':'https://tse4.mm.bing.net/th?id=OIP.C1nevB__9O-Cf4hW_vOk0gHaLH&pid=Api&P=0&h=180',
        'Description':'Name of Shop:A Cake shop,         Time:10:00am-5:00pm, Price:Rs.500/kg',
      },
      {
        'images':'https://tse2.mm.bing.net/th?id=OIP.KBxxa1NSGe5IKUJXs-zUkwHaHa&pid=Api&P=0&h=180',
        'Description':'Name of Shop:Old Cake shop,       Time:11:00am-5:00pm, Price:Rs.200/kg'
      },
      {
        'images':'https://tse2.mm.bing.net/th?id=OIP.f21V7Nf65W-W2kxwEJWJRwHaE8&pid=Api&P=0&h=180',
        'Description':'Name of Shop:Old Cake shop,       Time:11:00am-5:00pm, Price:Rs.250/kg',
      },

    ],


  };

  Color _getColor(String cake) {
    return cake == yourCake ? Colors.teal : Colors.tealAccent;
  }

  void _showCakes(String cake) {
    List<Map<String,String>> imagesData = cakeImages[cake] ?? [];
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: SizedBox(
            width: 300,
            height: 500,
            child: ListView.builder(
              itemCount: imagesData.length, itemBuilder: (context, index) {
                String images = imagesData[index]['images'] ?? '';
                String description = imagesData[index]['Description'] ?? '';
                return Column(
                  children: [Image.network(images),
                    const SizedBox(height: 10),
                    Text(description),
                    const Divider(),
                  ],
                );
              },
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.greenAccent,
        title: const Text('Cake Shops'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: () {
                setState(() {
                  yourCake = 'vanillaCake';
                });
                _showCakes('vanillaCake');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: _getColor('vanillaCake'),
              ),
              child: Text(vanillaCake),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  yourCake = 'strawberryCake';
                });
                _showCakes('strawberryCake');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: _getColor('strawberryCake'),
              ),
              child: Text(strawberryCake),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  yourCake = 'chocolateCake';
                });
                _showCakes('chocolateCake');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: _getColor('chocolateCake'),
              ),
              child: Text(chocolateCake),
            ),
            Text(
              'Your chosen flavour: $yourCake',
            ),
          ],
        ),
      ),
    );
  }
}
